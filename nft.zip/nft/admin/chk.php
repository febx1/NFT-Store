<?php
session_start();
echo 'The Name of the student is :' . $_SESSION['ADMIN_LOGIN'] . '<br>'; 
echo  $_SESSION['ADMIN_USERNAME'] ; 


?>