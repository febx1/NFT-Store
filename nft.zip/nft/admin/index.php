<?php  header('location:categories.php');
?>
